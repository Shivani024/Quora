# Quora clone.
- Project is around 80% complete still adding and changing design/features

# Features
- Firebase on the backend to store users and site information
- Users can ask, answer and vote on questions.
# Live Demo
View [Live Demo](https://jerrytnutt.github.io/Quora-clone/)


